package com.codegym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogAuthenticApplicationTests {

    @Test
    void contextLoads() {
    }

}
